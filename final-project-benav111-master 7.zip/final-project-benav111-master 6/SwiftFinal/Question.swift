//
//  Question.swift
//  SwiftFinal
//
//  Created by Benavidez, Amanda on 5/9/16.
//  Copyright © 2016 Benavidez, Amanda. All rights reserved.
//  Class for each individual question

import Foundation
class Question {
    var questionText : String
    var answerOption1 : String
    var answerOption2: String
    //final answer for a question, decides points(either 0 for cap or 1 for iron man)
    var finalAnswer: Int
    //variable deciding which side user is on(either 0 for cap or 1 for iron man)
    static var finalScore : Int = 0
    init(text:String, ans1: String, ans2: String)
    {
        self.questionText = text
        self.answerOption1 = ans1
        self.answerOption2 = ans2
        self.finalAnswer = 0
    }
}