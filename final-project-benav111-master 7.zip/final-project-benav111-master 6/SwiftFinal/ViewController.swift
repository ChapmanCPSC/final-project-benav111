//
//  ViewController.swift
//  SwiftFinal
//
//  Created by Benavidez, Amanda on 5/4/16.
//  Copyright © 2016 Benavidez, Amanda. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var homeLabel: UILabel!
    @IBOutlet weak var beginButton: UIButton!
    @IBOutlet weak var homeImage: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        homeImage.image = UIImage(named: "home")
        homeLabel.text = "Pick  A  Side!"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


    @IBAction func ButtonPressed(sender: AnyObject)
    {//opens view controller/starts quiz
        let navVC = self.storyboard!.instantiateViewControllerWithIdentifier("nav_controller") as! UINavigationController
        self.presentViewController(navVC, animated: true, completion: nil)
        
    }
}

