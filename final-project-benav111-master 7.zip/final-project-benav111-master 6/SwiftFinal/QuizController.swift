
//
//  QuizController.swift
//  SwiftFinal
//
//  Created by Benavidez, Amanda on 5/9/16.
//  Copyright © 2016 Benavidez, Amanda. All rights reserved.
//

import UIKit

class QuizController : UIViewController, UIPickerViewDataSource,UIPickerViewDelegate{

    var currentIndex = 0
    @IBOutlet weak var questionLabel: UILabel!
    @IBOutlet weak var answerPicker: UIPickerView!
    //all the questions to ask
    let questionsDict : [Int : Question] = [
        0 : Question(text : "How  do  you  feel  about  government  involvement?", ans1: "I don't like it", ans2: "It's necessary"),
        1: Question(text: "Do  you  believe  in  compromising  your  beliefs  for  the  benefit  of  others?", ans1: "No, my values are everything", ans2: "Yes, if its for the best"),
        2: Question(text:"Would  you  protect  your  friends  no  matter  the  cost?", ans1: "Always", ans2: "Not if they're in the wrong"),
        3: Question(text: "Do  you  make  decisions  based  on  gut-feeling  or  logic?", ans1: "Gut-feeling", ans2: "Logic"),
        4: Question(text: "Do  you  believe  being  right  is  more  important  than  being  curteous?", ans1: "No, it's better to be curteous", ans2: "Being right is more important"),
        5: Question(text: "Are  you  a  more  level-headed  or  anxious  person?", ans1: "Level-headed", ans2: "Anxious"),
        6: Question(text: "Do  you  find  yourself  living  in  the  past?", ans1: "I try not to", ans2: "I think about it often"),
        7: Question(text: "Do  you  pride  yourself  in  being  honorable  or  intellectual?", ans1: "Honorable", ans2: "Intellectual"),
        8: Question(text: "Would  you  prefer  a  quiet  night  in  or  a  wild  night  out?", ans1: "Quiet night in", ans2: "Wild night out"),
        9: Question(text: "How  do  you  take  your  coffee?", ans1: "Black", ans2: "With milk and sugar")]
    var currentQuestion : Question!
    var currentAnswer : String!
    override func viewDidLoad()
    {//setting sources
        questionLabel.text = questionsDict[0]?.questionText
        answerPicker.dataSource = self
        answerPicker.delegate = self
        currentQuestion = questionsDict[currentIndex]!
    }
    
    //returns the number of components in the picker view, we have only 1
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int
    {
        return 1
    }
    
    //returns the number of rows for the pickerview based on the number of items in our datasource, questionsDict dictionary
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int
    {
        return 2
    }
    
    
    //returns the correct data that corresponds to that particular row
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component:Int) -> String?
    {//presents 2 answer options per question
        if (row == 0)
        {
            return currentQuestion.answerOption1
        }
        else
        {
            return currentQuestion.answerOption2
        }
    }
    
    func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int)
    {//calculates points for the question based on answer picked (either 0 for cap or 1 for iron man)
        if (row == 0)
        {
            questionsDict[currentIndex]?.finalAnswer = 0
        }
        else
        {
            questionsDict[currentIndex]?.finalAnswer = 1
        }
    }
    
    @IBAction func nextPressed(sender: AnyObject) {
        if (currentIndex != 9)
        {//load next question if not at the end
            currentQuestion = questionsDict[++currentIndex]!
            questionLabel.text = questionsDict[currentIndex]?.questionText
            //to prevent from error where index resets
            answerPicker.reloadAllComponents()
            answerPicker.selectRow(0, inComponent: 0, animated: true)
        }
        else
        {//load sharing page
            calculateScore()
            let navVC = self.storyboard!.instantiateViewControllerWithIdentifier("nav_controller2") as! UINavigationController
            self.presentViewController(navVC, animated: true, completion: nil)
        }
    }
    
    func calculateScore() -> Int
    {//gets the points per question and tallies them up
        var score = 0
        for (i, q) in questionsDict
        {
            score += q.finalAnswer
        }
        if (score <= 5)
        {//needed tie breaker, default to cap
            //set final score(either 0 for cap or 1 for iron man)
            Question.finalScore = 0
            return 0
        }
        else
        {
            Question.finalScore = 1
            return 1
        }
    }
}