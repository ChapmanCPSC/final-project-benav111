//
//  ResultController.swift
//  SwiftFinal
//
//  Created by Benavidez, Amanda on 5/11/16.
//  Copyright © 2016 Benavidez, Amanda. All rights reserved.
//
import Social
import UIKit
class ResultController : UIViewController{
    
    @IBOutlet weak var sideLabel: UILabel!
    @IBOutlet weak var sideImageView: UIImageView!
    var initialText: String!
    var side : Int!
    var sideImage: UIImage!
    var capImage = UIImage(named: "cap")
    var ironImage = UIImage(named: "iron")
    override func viewDidLoad()
    {
        if (Question.finalScore == 0)
        {//get values for caps side
            sideLabel.text = "You're  on  Captain  America's  side!"
            sideImageView.image = capImage
            side = 0
            initialText = "I'm on Captain America's Side!"
            sideImage = capImage
        }
        else
        {//get values for iron mans side
            sideLabel.text = "You're  on  Iron Man's  side!"
            sideImageView.image = ironImage
            side = 1
            initialText = "I'm on Iron Man's Side!"
            sideImage = ironImage
        }
    }
    
    //help from: https://developer.apple.com/library/ios/documentation/NetworkingInternet/Reference/SLComposeViewController_Class/
    //https://www.codementor.io/swift/tutorial/ios-development-facebook-twitter-sharing
    @IBAction func tweetResult(sender: AnyObject) {
        //shares to twitter
        if (SLComposeViewController.isAvailableForServiceType(SLServiceTypeTwitter)){
            //if they're logged in then share
            let twitterView = SLComposeViewController(forServiceType: SLServiceTypeTwitter)
            //add content to share
            twitterView.setInitialText(initialText)
            twitterView.addImage(sideImage)
            //present view controller to share from
            self.presentViewController(twitterView, animated: true, completion: nil)
        } else {
            //if theyre not logged in then don't share
            //present error so they know why
            let loginMessage = UIAlertController(title: "Login Error", message: "You must login to Twitter in order to share this!", preferredStyle: UIAlertControllerStyle.Alert)
            //add an action they can respond with
            loginMessage.addAction(UIAlertAction(title: "Got it!", style: UIAlertActionStyle.Default, handler: nil))
            //present the view controller
            self.presentViewController(loginMessage, animated: true, completion: nil)
        }
    }
    @IBAction func shareResult(sender: AnyObject) {
        //shares to fb w/o initial text bc facebook no longer allows developers to do this, but image still works
        if (SLComposeViewController.isAvailableForServiceType(SLServiceTypeFacebook)){
            let facebookView = SLComposeViewController(forServiceType: SLServiceTypeFacebook)
            facebookView.addImage(sideImage)
            self.presentViewController(facebookView, animated: true, completion: nil)
        } else {
            let loginMessage = UIAlertController(title: "Login Error", message: "You must login to Facebook in order to share this!", preferredStyle: UIAlertControllerStyle.Alert)
            loginMessage.addAction(UIAlertAction(title: "Got it!", style: UIAlertActionStyle.Default, handler: nil))
            self.presentViewController(loginMessage, animated: true, completion: nil)
        }
    }
}
