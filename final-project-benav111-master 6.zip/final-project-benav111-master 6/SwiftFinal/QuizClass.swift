//
//  QuizClass.swift
//  SwiftFinal
//
//  Created by Benavidez, Amanda on 5/4/16.
//  Copyright © 2016 Benavidez, Amanda. All rights reserved.
//

import UIKit

class QuizClass {
    
}
