//
//  ResultController.swift
//  SwiftFinal
//
//  Created by Benavidez, Amanda on 5/11/16.
//  Copyright © 2016 Benavidez, Amanda. All rights reserved.
//

import UIKit
class ResultController : UIViewController{
    
    @IBOutlet weak var sideLabel: UILabel!
    @IBOutlet weak var sideImageView: UIImageView!
    @IBOutlet weak var twitterButton: UIButton!
    @IBOutlet weak var facebookButton: UIButton!
    override func viewDidLoad()
    {
        if (Question.finalScore == 0)
        {
            sideLabel.text = "You're on Captain America's side!"
        }
        else
        {
            sideLabel.text = "You're on Iron Man's side!"

        }
    }
}
